<?php
$frontpage_content = "<h3>Laporan Tahunan</h3>\n<p>\n";
//$frontpage_content .= "<div id=\"slider\">\n<ul>\n";
$frontpage_content .= "<img src=\"simpleplot3y.php\" >\n";
//frontpage_content .= "<img src=\"simpleplot4.php\" >\n";
//$frontpage_content .= "<img src=\"simpleplot4b.php\" >\n";
//$frontpage_content .= "<img src=\"simpleplot4c.php\" >\n";
//$frontpage_content .= "<img src=\"simpleplot4d.php\" >\n";
//$frontpage_content .= "<img src=\"simpleplot4e.php\" >\n";
//$frontpage_content .= "<img src=\"simpleplot4f.php\" >\n";
//$frontpage_content .= "</ul>\n</div>\n";
$frontpage_content .= "</p>\n";
?>